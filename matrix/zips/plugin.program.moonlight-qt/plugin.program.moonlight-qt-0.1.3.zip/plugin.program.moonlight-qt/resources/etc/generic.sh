# Fixes SDL error: Could not initialize OpenGL / GLES library
export SDL_VIDEO_GL_DRIVER=/usr/lib/libGL.so
