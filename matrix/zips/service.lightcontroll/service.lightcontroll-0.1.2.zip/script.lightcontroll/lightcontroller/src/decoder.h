#ifndef DECODER
#define DECODER

#define HARDWAREVERSION "1.0"
#define SOFTWAREVERSION "2.0"


void decoder(char *s, int len);

#endif
