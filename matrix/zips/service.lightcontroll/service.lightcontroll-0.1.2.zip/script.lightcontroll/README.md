# Lightcontroll plugin

This plugin script is responsible for interfacing between Kodi and my lightcontroll microcontroller. It is completely self developed, however the basic structure can be used for similar plugins if it helps you. Released under the Apache 2.0 license.
