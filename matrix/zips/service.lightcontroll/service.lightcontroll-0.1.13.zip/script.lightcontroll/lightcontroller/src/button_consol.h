#ifndef BUTTON_CONSOL_H
#define BUTTON_CONSOL_H

void check_buttons(void);

void button_test(void);

void button_decoder_init(void);

void button_decoder(char *s, int len);

#endif
